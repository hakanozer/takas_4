
package com.works.twodays.props;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Product {

    @SerializedName("durum")
    @Expose
    private boolean durum;
    @SerializedName("mesaj")
    @Expose
    private String mesaj;
    @SerializedName("bilgiler")
    @Expose
    private List<Bilgiler> bilgiler = null;

    public boolean isDurum() {
        return durum;
    }

    public void setDurum(boolean durum) {
        this.durum = durum;
    }

    public String getMesaj() {
        return mesaj;
    }

    public void setMesaj(String mesaj) {
        this.mesaj = mesaj;
    }

    public List<Bilgiler> getBilgiler() {
        return bilgiler;
    }

    public void setBilgiler(List<Bilgiler> bilgiler) {
        this.bilgiler = bilgiler;
    }

}
