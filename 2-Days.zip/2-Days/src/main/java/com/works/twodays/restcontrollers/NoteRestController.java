package com.works.twodays.restcontrollers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.works.twodays.entities.Note;
import com.works.twodays.props.Bilgiler;
import com.works.twodays.props.ProductData;
import com.works.twodays.repositories.NoteRepository;
import com.works.twodays.utils.ERest;

@RestController
@RequestMapping("/note")
public class NoteRestController {
	
	final NoteRepository nRepo;
	final CacheManager cacheManager;
	public NoteRestController( NoteRepository nRepo, CacheManager cacheManager ) {
		this.nRepo = nRepo;
		this.cacheManager = cacheManager;
	}

	
	@PostMapping("/insert")
	public Map<ERest, Object> insert( @Valid @RequestBody Note note ) {
		Map<ERest, Object> hm = new LinkedHashMap<>();
		
		hm.put(ERest.status, true);
		hm.put(ERest.result, nRepo.saveAndFlush(note) );
		
		cacheClear("list");
		
		return hm;
	}
	
	
	@GetMapping("/list")
	@Cacheable("list")
	public Map<ERest, Object> list() {
		Map<ERest, Object> hm = new LinkedHashMap<>();
		hm.put(ERest.status, true);
		hm.put( ERest.result, nRepo.findAll() );
		hm.put(ERest.news, productList());
		System.out.println("=====list Call=====");
		return hm;
	}
	
	
	public List<Bilgiler> productList() {
		
		try {
			
			String url = "http://jsonbulut.com/json/product.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24&start=0";
			RestTemplate restTemplate = new RestTemplate();
			String sData = restTemplate.getForObject(url, String.class);
			
			Gson gson = new Gson();
			ProductData data = gson.fromJson(sData, ProductData.class);
			
			return data.getProducts().get(0).getBilgiler();

			
		} catch (Exception e) {
			System.err.println("Product Error : " + e);
		}
		
		return null;
		
	}
	
	
	@DeleteMapping("/singleDetete")
	public Map<ERest, Object> singleDete( @RequestBody Note note ) {
		Map<ERest, Object> hm = new LinkedHashMap<>();
		
		try {
			int nid = Integer.valueOf(note.getNid());
			nRepo.deleteById(nid);
			hm.put(ERest.status, true);
			hm.put(ERest.message, "Delete Success: " + note.getNid());
		} catch (Exception e) {
			hm.put(ERest.status, false);
			hm.put(ERest.message, "Delete Fail: " + note.getNid());
		}
		
		
		return hm;
	}
	
	
	@PutMapping("/update")
	public Map<ERest, Object> update( @RequestBody Note note ) {
		Map<ERest, Object> hm = new LinkedHashMap<>();
		
		Optional<Note> opn = nRepo.findById(note.getNid());
		if ( opn.isPresent() ) {
			
			hm.put(ERest.status, true);
			hm.put(ERest.result, nRepo.saveAndFlush(note) );
			
		}else {
			hm.put(ERest.status, false);
			hm.put(ERest.result, null );
		}
		
		return hm;
	}
	
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, Object> exHandle( MethodArgumentNotValidException ex ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		List<ObjectError> els = ex.getBindingResult().getAllErrors();
		List<Map<String, String>> hmls = new ArrayList<>();
		for (ObjectError item : els) {
			Map<String, String> hm_item = new HashMap<>();
			String field = (( FieldError ) item).getField();
			String message = item.getDefaultMessage();
			hm_item.put("field", field);
			hm_item.put("message", message);
			hmls.add(hm_item);
		}
		
		hm.put("status", false);
		hm.put("error", hmls);
		
		return hm;
	}
	
	
	public void cacheClear( String cacheName ) {
		cacheManager.getCache(cacheName).clear();
	}
	
	@Scheduled(fixedDelay = 5000)
	public void timerFnc() {
		System.out.println("timerFnc Call");
		cacheClear("list");
	}
	
	
	
}
