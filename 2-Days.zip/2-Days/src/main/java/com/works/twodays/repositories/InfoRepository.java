package com.works.twodays.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.works.twodays.entities.Info;

public interface InfoRepository extends JpaRepository<Info, Integer> {

}
