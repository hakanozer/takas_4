package com.works.twodays.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import com.works.twodays.customValid.Category;

import lombok.Data;

@Entity
@Data
public class Note {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer nid;
	
	@NotNull(message = "n_title @NotNull")
	@NotEmpty(message = "n_title @NotEmpty")
	@Length(min = 5, max = 50, message = "n_title @Length min = 5, max = 50")
	private String n_title;
	
	@NotNull(message = "n_detail @NotNull")
	@NotEmpty(message = "n_detail @NotEmpty")
	private String n_detail;
	
	@Category(message = "Category Is Not Allowed Data")
	private String category;

}
