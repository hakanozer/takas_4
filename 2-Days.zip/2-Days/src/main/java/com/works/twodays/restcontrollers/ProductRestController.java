package com.works.twodays.restcontrollers;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.works.twodays.entities.Product;
import com.works.twodays.repositories.ProductRepository;
import com.works.twodays.utils.ERest;

@RestController
@RequestMapping("/product")
public class ProductRestController {
	
	final ProductRepository pRepo;
	public ProductRestController( ProductRepository pRepo ) {
		this.pRepo = pRepo;
	}
	
	
	@PostMapping("/insert")
	public Map<ERest, Object> insert( @RequestBody Product product ) {
		Map<ERest, Object> hm = new LinkedHashMap<>();
		
		hm.put(ERest.status, true);
		hm.put(ERest.result, pRepo.saveAndFlush(product) );
		
		return hm;
	}
	
	
	@GetMapping("/list")
	public Map<ERest, Object> list() {
		Map<ERest, Object> hm = new LinkedHashMap<>();
		hm.put(ERest.status, true);
		hm.put( ERest.result, pRepo.findAll() );
		return hm;
	}
	
	
	@DeleteMapping("/singleDetete")
	public Map<ERest, Object> singleDete( @RequestBody Product product ) {
		Map<ERest, Object> hm = new LinkedHashMap<>();
		
		try {
			int nid = Integer.valueOf(product.getPid());
			pRepo.deleteById(nid);
			hm.put(ERest.status, true);
			hm.put(ERest.message, "Delete Success: " + product.getPid());
		} catch (Exception e) {
			hm.put(ERest.status, false);
			hm.put(ERest.message, "Delete Fail: " + product.getPid());
		}
		
		
		return hm;
	}
	
	
	@PutMapping("/update")
	public Map<ERest, Object> update( @RequestBody Product product ) {
		Map<ERest, Object> hm = new LinkedHashMap<>();
		
		Optional<Product> opn = pRepo.findById(product.getPid());
		if ( opn.isPresent() ) {
			
			hm.put(ERest.status, true);
			hm.put(ERest.result, pRepo.saveAndFlush(product) );
			
		}else {
			hm.put(ERest.status, false);
			hm.put(ERest.result, null );
		}
		
		return hm;
	}

}
