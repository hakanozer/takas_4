package com.works.twodays.utils;

public enum ERest {

	status, result, message, news, error;
	
}
