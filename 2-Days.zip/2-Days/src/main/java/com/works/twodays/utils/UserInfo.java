package com.works.twodays.utils;

import java.util.Collection;
import java.util.Date;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.works.twodays.entities.Info;
import com.works.twodays.repositories.InfoRepository;

@Service
public class UserInfo {
	
	final InfoRepository iRepo;
	public UserInfo( InfoRepository iRepo ) {
		this.iRepo = iRepo;
	}
	

	public void info(String path) {
		
		Authentication aut = SecurityContextHolder.getContext().getAuthentication();
		Collection<? extends GrantedAuthority> cls = aut.getAuthorities();
		
		StringBuilder builder = new StringBuilder();
		builder.append("[ ");
		for (GrantedAuthority grantedAuthority : cls) {
			builder.append(grantedAuthority.getAuthority());
			builder.append(" ");
		}
		builder.append("]");
		
		String name = aut.getName();
		String detail = aut.getDetails().toString();
		String roles = builder.toString();
		
		Info info = new Info();
		info.setDetail(detail);
		info.setDate(new Date());
		info.setName(name);
		info.setPath(path);
		info.setRoles(roles);
		
		
		iRepo.saveAndFlush(info);
		
		System.out.println(name + " " + roles + " " + path + " " + detail);
		
	}
	

}
