package com.works.twodays.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.works.twodays.entities.Note;

public interface NoteRepository extends JpaRepository<Note, Integer> {
	

}
