package com.works.onedays.controllers;

import javax.servlet.http.Cookie;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.works.onedays.entities.UserLogin;
import com.works.onedays.services.UserService;
import com.works.onedays.utils.Util;

@Controller
public class UserLoginController {

	final UserService service;

	public UserLoginController(UserService service) {
		this.service = service;
	}

	@GetMapping("/userLogin")
	public String userLogin() {
		String start_id = service.req.getSession().getId();
		System.out.println("start_id : " + start_id);

		if (service.req.getCookies() != null) {
			Cookie[] cookies = service.req.getCookies();
			for (Cookie cookie : cookies) {
				if (!cookie.getName().equals("user_session")) {
					Cookie cookiex = new Cookie("user_session", Util.sifrele(start_id, 4));
					cookie.setMaxAge(5000);
					service.res.addCookie(cookiex);
				}
			}
		}

		return "userLogin";
	}

	@PostMapping("/userLogin")
	public String userLogin(UserLogin login) {
		boolean status = service.loginControl(login);
		if (status) {
			return "redirect:/dashboard";
		}
		return "userLogin";
	}

	@GetMapping("/logOut")
	public String logOut() {
		service.logOut();
		return "redirect:/userLogin";
	}

}
