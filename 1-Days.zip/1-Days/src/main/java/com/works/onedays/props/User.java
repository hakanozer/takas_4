package com.works.onedays.props;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import lombok.Data;

@Data
public class User {
	
	@NotNull(message = "email @NotNull")
	@NotEmpty(message = "email @NotEmpty")
	@Email(message = "email Not valid format")
	private String email;
	
	@NotNull(message = "password @NotNull")
	@NotEmpty(message = "password @NotEmpty")
	@Length(min = 3, max = 15, message = "password min = 3, max = 15")
	private String password;
	private String remember;


}
