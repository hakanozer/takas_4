package com.works.onedays.services;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import com.works.onedays.entities.UserLogin;
import com.works.onedays.utils.Util;

@Service
public class UserService {
	
	@Autowired DriverManagerDataSource db;
	final public HttpServletRequest req;
	final public HttpServletResponse res;
	public UserService( HttpServletRequest req,HttpServletResponse res ) {
		this.req = req;
		this.res = res;
	}
	
	public boolean loginControl( UserLogin login ) {
		
		boolean status = false;
	
		try {
			
			// select * from user_login where email = 'aaaaa@xxx.com' and pass = '' or 1=1 --'
			/*
			String sql = "select * from user_login where email = '"+login.getEmail()+"' and password = '"+login.getPassword()+"' ";
			Statement st = db.getConnection().createStatement();
			ResultSet rs = st.executeQuery(sql);
			*/
			
			String sqll = "select * from user_login where email = ? and password = ?";
			PreparedStatement pre = db.getConnection().prepareStatement(sqll);
			pre.setString(1, login.getEmail());
			pre.setString(2, Util.MD5(login.getPassword()));
			ResultSet rss = pre.executeQuery();
			

			if (rss.next()) {
				System.out.println("User Login Success");
				status = true;
				
				// session create
				login.setPassword(null);
				login.setUid(rss.getInt("uid"));
				login.setName(rss.getString("name"));
				req.getSession().setAttribute("user", login);
				
			}else {
				System.out.println("User Login Fail");
			}
			
		} catch (Exception e) {
			System.err.println("loginControl Error : " + e);
		}
		
		return status;
		
	}
	
	
	public String control( String page ) {
		
		String end_id = req.getSession().getId();
		System.out.println("end_id : " + end_id);
		//req.getSession().invalidate();
		
		if ( req.getCookies() != null ) {
			Cookie[] cookies = req.getCookies();
			for (Cookie cookie : cookies) {
				if ( cookie.getName().equals("user_session") ) {
					String val = Util.sifreCoz(cookie.getValue(), 4);
					if ( !val.equals(end_id) ) {
						req.getSession().invalidate();
						return "redirect:/userLogin";
					}
				}
			}
		}
		
		
		boolean status = req.getSession().getAttribute("user") != null;
		if ( status ) {
			return page;
		}
		
		return "redirect:/userLogin";
		
	}
	
	
	public UserLogin user() {
		
		UserLogin login = new UserLogin(); 
		boolean status = req.getSession().getAttribute("user") != null;
		if ( status ) {
			login = ( UserLogin ) req.getSession().getAttribute("user");
		}
		return login;
		
	}
	
	
	public void logOut() {
		
		// single user session remove
		req.getSession().removeAttribute("user");
		// all user session remove
		req.getSession().invalidate();
		
		Cookie cookie = new Cookie("user_session", "");
		cookie.setMaxAge(0);
		res.addCookie(cookie);
		
	}
	
	
	

}
