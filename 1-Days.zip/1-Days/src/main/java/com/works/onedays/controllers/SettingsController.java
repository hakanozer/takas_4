package com.works.onedays.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.works.onedays.services.UserService;

@Controller
public class SettingsController {
	
	final UserService service;
	public SettingsController( UserService service ) {
		this.service = service;
	}

	@GetMapping("/settings")
	public String settings() {
		return service.control("settings");
	}
	
}
