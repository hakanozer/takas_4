package com.works.onedays.controllers;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.works.onedays.props.User;

@Controller
public class LoginController {

	
	@GetMapping("/")
	public String login( Model model ) {
		model.addAttribute("userValid", new User());
		return "login";
	}
	
	
	@PostMapping("/userAction")
	public String userAction( @Valid @ModelAttribute("userValid") User user, BindingResult bind , Model model ) {
		
		if ( bind.hasErrors() ) {
			
		}else {
			model.addAttribute("email", user.getEmail());
		}

		return "login";
	}
	
	
	@PostMapping("/erros")
	public String erros() {
		return "redirect:/errosPage";
	}
	
	@GetMapping("/errosPage")
	public String errosPage() {
		return "erros";
	}
	
}
