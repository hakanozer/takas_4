package com.works.onedays.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.works.onedays.services.UserService;

@Controller
public class DashboardController {
	
	final UserService service;
	public DashboardController( UserService service ) {
		this.service = service;
	}

	@GetMapping("/dashboard")
	public String dashboard() {
		return service.control("dashboard");
	}
	
}
