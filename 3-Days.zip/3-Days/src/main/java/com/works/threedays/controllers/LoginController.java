package com.works.threedays.controllers;

import java.util.UUID;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {
	
	String uuid = "";

	@GetMapping("/")
	public String login( Model model ) {
		uuid = UUID.randomUUID().toString();
		System.out.println(uuid);
		model.addAttribute("csrf", uuid);
		return "login";
	}
	
	
	@PostMapping("/userLogin")
	public String userLogin( 
			@RequestParam String email, 
			@RequestParam String pass,
			@RequestParam String csrf
			) {
		
		if ( csrf.equals(uuid) ) {
			System.out.println(email + " " + pass);
		}else {
			System.err.println("Form Send Error ");
		}
		
		return "redirect:/";
	}
	
	
}
