package com.works.threedays.useProfile;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("dev")
public class Development implements ConfigProfile {

	@Override
	public Map<CEnum, Object> config() {
		Map<CEnum, Object> hm = new LinkedHashMap<>();
		
		hm.put(CEnum.apiKey, "devApi123456uqwefghj");
		hm.put(CEnum.count, 50);
		hm.put(CEnum.timeOut, 30);
		
		return hm;
	}

	
}
