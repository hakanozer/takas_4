package com.works.threedays.usingThread;

public class UseMainThread {

	public static void main(String[] args) throws InterruptedException {

		Runnable rn = () -> {
			
			try {

				Action ac1 = new Action("th1", 10);
				Action ac2 = new Action("th2", 15);
				Action ac3 = new Action("th3", 20);
				Action ac4 = new Action("th4", 25);
				Action ac5 = new Action("th5", 30);

				ac1.start();
				ac1.join();

				ac2.start();
				ac2.join();

				ac3.start();
				ac3.join();

				ac4.start();
				ac4.join();

				ac5.start();
				ac5.join();

			} catch (Exception e) {
			}

		};
		new Thread(rn).start();

		System.out.println("This Line Call");

	}

}
