package com.works.threedays.useProfile;

public enum CEnum {
	
	apiKey, count, timeOut;

}
