package com.works.threedays.useProfile;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("prod")
public class Product implements ConfigProfile {

	@Override
	public Map<CEnum, Object> config() {
		Map<CEnum, Object> hm = new LinkedHashMap<>();
		
		hm.put(CEnum.apiKey, "prodApi123456uqwefghj");
		hm.put(CEnum.count, 20);
		hm.put(CEnum.timeOut, 15);
		
		return hm;
	}

	
}