package com.works.threedays.usingThread;

public class Action extends Thread {
	
	int count = 0;
	String name = "";
	public Action( String name, int count ) {
		this.count = count;
		this.name = name;
	}

	@Override
	public void run() {
		
		try {
			
			for (int i = 0; i < count; i++) {
				Thread.sleep(500);
				System.out.println( name + " " + "Count : " + i);
			}
			
		} catch (Exception e) {}
		
	}
	
}
