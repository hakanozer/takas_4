package com.works.threedays.useProfile;

import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public interface ConfigProfile {

	Map<CEnum, Object> config();
	
}
