package com.works.threedays.restcontrollers;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.works.threedays.entities.UserInfo;
import com.works.threedays.repositories.UserInfoRepository;
import com.works.threedays.useTink.TinkDecrypt;
import com.works.threedays.useTink.TinkEncrypt;

@RestController
public class UserInfoRestController {

	final UserInfoRepository uInfo;
	public UserInfoRestController( UserInfoRepository uInfo ) {
		this.uInfo = uInfo;
	}
	
	@PostMapping("/infoInsert")
	public Map<String, Object> infoInsert( @RequestBody UserInfo info ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		
		info.setCipherText(TinkEncrypt.encrypt(info.getKey128Bit(), info.getCipherText(), info.getAssociatedData()));
		hm.put("result", uInfo.saveAndFlush( info ));
		
		return hm;
	}
	
	
	@PostMapping("/infoSelect")
	public Map<String, Object> infoSelect( @RequestBody UserInfo info ) {
		Map<String, Object> hm = new LinkedHashMap<>();
	
		Optional<UserInfo> infoDb = uInfo.decInfo(info.getUid(), info.getKey128Bit(), info.getAssociatedData());
		if ( infoDb.isPresent() ) {
			UserInfo inf = infoDb.get();
			String plainText = TinkDecrypt.decrypt(inf.getKey128Bit(), inf.getCipherText(), inf.getAssociatedData());
			String[] arr = plainText.split("_");
			hm.put("result", arr);
		}else {
			hm.put("result", null);
		}
		
		
		return hm;
	}
	
	
}
