package com.works.threedays.usingThread;

import java.util.concurrent.CompletableFuture;

public class UseComplatable {

	public static void main(String[] args) {
		
		
		CompletableFuture<Void> cf1 = CompletableFuture.runAsync( () -> {
			
			try {
				
				for (int i = 0; i < 10; i++) {
					Thread.sleep(500);
					System.out.println(Thread.currentThread().getName() + " i: " + i );
				}
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		});
		
		
		CompletableFuture<Void> cf2 = CompletableFuture.runAsync( () -> {
			
			try {
				
				for (int i = 0; i < 20; i++) {
					Thread.sleep(500);
					System.out.println(Thread.currentThread().getName() + " i: " + i );
				}
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		});
		
		CompletableFuture<Void> allOff = CompletableFuture.allOf(cf1,cf2 );
		allOff.join();
		System.out.println("All Thread Finish");
		

	}

}
