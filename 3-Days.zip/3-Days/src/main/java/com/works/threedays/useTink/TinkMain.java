package com.works.threedays.useTink;

public class TinkMain {
	
	/*

	public static void main(String[] args) {
		
		
		String key128Bit = "(G+KbPeShVmYp3s6";
		String plainText = "404_true_50_12345";
		String associatedData = "ext_key";
		

		TinkEncrypt tinkEncrypt = new TinkEncrypt();
		String cipherText = tinkEncrypt.encrypt(key128Bit, plainText, associatedData);
		System.out.println(cipherText);
		
		
		String key128Bit = "(G+KbPeShVmYp3s6";
		String cipherText = "¤t¤oß	_2qØ<Å4²IáØßï>IÏdmFýÕ³|2D|Ô";
		String associatedData = "ext_key";
		
		TinkDecrypt tinkDecrypt = new TinkDecrypt();
		String plainText = tinkDecrypt.decrypt(key128Bit, cipherText, associatedData);
		System.out.println(plainText);
		

	}
*/

}
