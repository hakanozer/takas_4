package com.works.threedays.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;

import com.works.threedays.entities.UserInfo;

public interface UserInfoRepository extends JpaRepository<UserInfo, Integer> {

	//@Procedure("Call proInfo(?1,?2,?3)")
	@Query(" select u from UserInfo u where u.uid = ?1 and u.key128Bit = ?2 and u.associatedData = ?3 ")
    Optional<UserInfo> decInfo( int uid, String key128Bit, String associatedData );	
	
}
