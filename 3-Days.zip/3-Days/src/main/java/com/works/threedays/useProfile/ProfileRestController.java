package com.works.threedays.useProfile;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProfileRestController {
	
	final ConfigProfile cProfile;
	public ProfileRestController( ConfigProfile cProfile ) {
		this.cProfile = cProfile;
	}
	
	
	@GetMapping("/profile")
	public Map<String, Object> profile() {
		Map<String, Object> hm = new HashMap<>();
		hm.put("status", true);
		hm.put("config", cProfile.config());
		return hm;
	}

}
